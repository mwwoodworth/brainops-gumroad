# Notion Automation Recipes

To supercharge your template:

1. **Notion -> Slack**:
   - Use Notion's native Slack integration to post to #proj-updates when a Project status changes to "Done".

2. **Recurring Tasks**:
   - Use a button inside the template to "Generate Weekly Tasks" (Manual) or set up a Make.com automation to create rows every Monday.
