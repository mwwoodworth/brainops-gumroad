# Core AI Prompts Bundle - Start Here

This bundle includes:
1. Roofing Estimation Intelligence
2. PM Accelerator
3. Launch Optimizer

## Accessing Your Products
Navigate to the specific folders included in your download (or unzip the individual files provided) to access the READMEs for each specific product.

- `PROD_AI_ROOF_01/`
- `PROD_AI_PM_01/`
- `PROD_AI_LAUNCH_01/`

## Support
Contact: support@brainops.com