Core AI Prompt Bundle - Contains ROOFINT, PMACC, LAUNCH products
