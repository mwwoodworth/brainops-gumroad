# Weekly Project Status Report

**Project:** [Name]
**Date:** [Date]
**Status:** [Green/Yellow/Red]

## Executive Summary
[2-3 lines on overall health and major achievements]

## Key Accomplishments (Last Week)
- [Done Item 1]
- [Done Item 2]

## Upcoming Focus (Next Week)
- [Planned Item 1]
- [Planned Item 2]

## Risks & Blockers
| Risk | Impact | Mitigation | Owner |
|------|--------|------------|-------|
|      |        |            |       |

## Timeline/Budget Check
- **Schedule:** [On Track / X days behind]
- **Budget:** [On Track / X% over/under]
