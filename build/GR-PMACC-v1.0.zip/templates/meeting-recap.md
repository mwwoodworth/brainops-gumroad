# Meeting Recap: [Meeting Name]
**Date:** [Date]
**Attendees:** [List]

## Objectives
1. [Goal 1]
2. [Goal 2]

## Decisions Made
- [Decision 1]
- [Decision 2]

## Action Items
- [ ] **[Owner]**: [Task] (Due: [Date])
- [ ] **[Owner]**: [Task] (Due: [Date])

## Next Steps
- Next meeting: [Date/Time]
