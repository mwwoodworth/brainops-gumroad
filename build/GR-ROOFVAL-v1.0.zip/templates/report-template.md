# Lead Validation Report

**Date:** [Date]
**Total Leads Processed:** [Number]

## Summary
- Valid Addresses: [Number]
- Invalid/Review Needed: [Number]

## Action Items
- Review the "Invalid" list manually.
- Export "Valid" leads to CRM.
