Automation Pack Bundle - Contains ONBOARD, CONTENT, ROOFVAL products
